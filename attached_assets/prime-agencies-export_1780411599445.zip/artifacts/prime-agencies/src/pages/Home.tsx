import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  FaWhatsapp,
  FaFacebook,
  FaLinkedin,
  FaTwitter,
  FaPhone,
} from "react-icons/fa";
import { Menu, X, Truck, CheckCircle, Handshake, Package } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeIn = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};

function useCountUp(target: number, duration = 1800, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [start, target, duration]);
  return count;
}

const categories = [
  {
    name: "Veterinary Injection",
    image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400",
  },
  {
    name: "Veterinary Medicine",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400",
  },
  {
    name: "Dog Shampoo",
    image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400",
  },
  {
    name: "Pet Products",
    image: "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=400",
  },
  {
    name: "Veterinary Dry Injections",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400",
  },
  {
    name: "Animal Feed Supplement",
    image: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=400",
  },
  {
    name: "Antibacterial Drugs",
    image: "https://images.unsplash.com/photo-1550572017-26b5655c1f3f?w=400",
  },
  {
    name: "Pharmaceutical Capsules",
    image: "https://images.unsplash.com/photo-1628771065518-0d82f1938462?w=400",
  },
];

const products = [
  {
    name: "Mastazoct Tazo Inj 3375mg",
    specs: ["Veterinary Injection", "3375mg strength", "For professional use"],
    image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400",
  },
  {
    name: "Dorahit Inj 50ml",
    specs: ["Veterinary Injection", "50ml vial", "Sterile preparation"],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400",
  },
  {
    name: "Catosal 100ml",
    specs: ["Veterinary Medicine", "100ml vial", "Phosphorus compound"],
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400",
  },
  {
    name: "Ketochlor Shampoo",
    specs: ["Dog Shampoo", "Medicated formula", "Antifungal and antibacterial"],
    image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400",
  },
  {
    name: "Dectomax 50ml",
    specs: ["Veterinary Dry Injection", "50ml vial", "Antiparasitic"],
    image: "https://images.unsplash.com/photo-1550572017-26b5655c1f3f?w=400",
  },
  {
    name: "Savavet Renadyl",
    specs: ["Pharmaceutical Capsule", "Renal support", "Veterinary grade"],
    image: "https://images.unsplash.com/photo-1628771065518-0d82f1938462?w=400",
  },
];

const whyChooseUs = [
  {
    icon: <Truck className="w-8 h-8" />,
    title: "Fast Dispatch",
    desc: "Bulk orders shipped across Maharashtra with reliable logistics.",
  },
  {
    icon: <CheckCircle className="w-8 h-8" />,
    title: "Quality Assured",
    desc: "All products sourced exclusively from verified manufacturers.",
  },
  {
    icon: <Handshake className="w-8 h-8" />,
    title: "50+ Partners",
    desc: "Trusted by clinics, hospitals and distributors across the region.",
  },
  {
    icon: <Package className="w-8 h-8" />,
    title: "10,000+ Products",
    desc: "Largest veterinary product catalogue in the region.",
  },
];

function StatCard({
  value,
  label,
  numeric,
  suffix,
  index,
}: {
  value: string;
  label: string;
  numeric?: number;
  suffix?: string;
  index: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const counted = useCountUp(numeric ?? 0, 1600, started && !!numeric);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="bg-white rounded-xl shadow-lg border border-border p-6 text-center"
      data-testid={`stat-box-${index}`}
    >
      <div className="text-2xl md:text-3xl font-bold text-primary mb-1">
        {numeric && started ? `${counted}${suffix ?? ""}` : value}
      </div>
      <div className="text-sm font-medium text-muted-foreground">{label}</div>
    </div>
  );
}

export default function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: "smooth" });
  };

  const stats = [
    { value: "2014", label: "Established" },
    { value: "8+", label: "Product Categories", numeric: 8, suffix: "+" },
    { value: "50+", label: "Direct Partner Companies", numeric: 50, suffix: "+" },
    { value: "10,000+", label: "Products in Catalogue", numeric: 10000, suffix: "+" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* NAVBAR */}
      <nav className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-sm border-b shadow-sm">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            <div
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => scrollToSection("home")}
              data-testid="nav-logo"
            >
              <span className="text-2xl font-bold tracking-tight text-primary">
                Prime <span className="text-accent">Agencies</span>
              </span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              {["home", "products", "about", "contact"].map((link) => (
                <button
                  key={link}
                  onClick={() => scrollToSection(link)}
                  className="text-sm font-medium capitalize hover:text-accent transition-colors duration-200"
                  data-testid={`nav-${link}`}
                >
                  {link}
                </button>
              ))}
              <Button
                onClick={() => scrollToSection("contact")}
                className="bg-accent hover:bg-accent/90 text-white font-semibold shadow-md px-6 transition-all duration-200"
                data-testid="nav-cta"
              >
                Get a Quote
              </Button>
            </div>

            <button
              className="md:hidden p-2 text-foreground"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="nav-mobile-toggle"
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden border-t bg-white" data-testid="nav-mobile-menu">
            <div className="flex flex-col p-4 gap-2">
              {["home", "products", "about", "contact"].map((link) => (
                <button
                  key={link}
                  onClick={() => scrollToSection(link)}
                  className="text-left font-medium capitalize p-2 hover:bg-muted rounded-md transition-colors duration-200"
                >
                  {link}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* HERO */}
      <section
        id="home"
        className="relative pt-24 pb-32 lg:pt-36 lg:pb-40 overflow-hidden bg-gradient-to-br from-primary to-[#0f2442]"
      >
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10 mix-blend-overlay"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1583337130417-3346a1be7dee?q=80&w=2688&auto=format&fit=crop')" }}
        />
        <div className="container relative z-10 mx-auto px-4 lg:px-8 text-center text-white">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="max-w-4xl mx-auto"
          >
            <motion.h1
              variants={fadeIn}
              className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight"
              data-testid="hero-heading"
            >
              Your Trusted Veterinary <br className="hidden md:block" />
              Products Distributor
            </motion.h1>
            <motion.p
              variants={fadeIn}
              className="text-lg md:text-xl text-blue-100 mb-10 max-w-2xl mx-auto"
              data-testid="hero-subheading"
            >
              Based in Ulhasnagar, Maharashtra. Serving veterinary professionals
              and businesses with uncompromising quality and reliability since 2014.
            </motion.p>
            <motion.div
              variants={fadeIn}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <Button
                size="lg"
                onClick={() => scrollToSection("products")}
                className="bg-accent hover:bg-accent/90 text-white w-full sm:w-auto px-8 h-14 text-lg font-semibold shadow-lg shadow-accent/20 transition-all duration-200"
                data-testid="hero-btn-products"
              >
                View Products
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection("contact")}
                className="border-white/40 text-white bg-white/10 w-full sm:w-auto px-8 h-14 text-lg font-semibold hover:bg-white/20 transition-all duration-200"
                data-testid="hero-btn-quote"
              >
                Get a Quote
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* STATS BAR */}
      <section className="relative z-20 -mt-12">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat, i) => (
              <StatCard key={i} {...stat} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCT CATEGORIES */}
      <section id="products" className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Our Product Range
            </h2>
            <p className="text-muted-foreground text-lg">
              Comprehensive veterinary solutions meticulously sourced to meet the
              highest standards of clinical care.
            </p>
          </div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {categories.map((cat, i) => (
              <motion.div
                key={i}
                variants={fadeIn}
                className="group relative h-64 rounded-xl overflow-hidden cursor-pointer shadow-md hover:shadow-xl transition-all duration-300"
                style={{ border: "2px solid transparent" }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "#f5820d")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "transparent")}
                data-testid={`category-card-${i}`}
                onClick={() => scrollToSection("contact")}
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ backgroundImage: `url('${cat.image}')` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10" />
                <div className="absolute inset-0 flex flex-col justify-end p-5">
                  <h3 className="text-white font-bold text-lg leading-tight mb-2">
                    {cat.name}
                  </h3>
                  <div className="translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <span className="inline-block bg-accent text-white text-sm font-semibold px-4 py-1.5 rounded-full">
                      Explore &rarr;
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                Featured Inventory
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl">
                High-demand clinical supplies readily available for bulk dispatch
                across Maharashtra.
              </p>
            </div>
            <Button
              onClick={() => scrollToSection("contact")}
              className="bg-primary hover:bg-primary/90 text-white font-medium shrink-0 transition-all duration-200"
              data-testid="featured-btn-all"
            >
              Request Full Catalogue
            </Button>
          </div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {products.map((prod, i) => (
              <motion.div
                key={i}
                variants={fadeIn}
                className="group bg-white rounded-xl overflow-hidden border border-border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col"
                style={{ borderTop: "3px solid transparent" }}
                onMouseEnter={(e) => (e.currentTarget.style.borderTopColor = "#f5820d")}
                onMouseLeave={(e) => (e.currentTarget.style.borderTopColor = "transparent")}
                data-testid={`product-card-${i}`}
              >
                <div className="h-44 overflow-hidden relative">
                  <img
                    src={prod.image}
                    alt={prod.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-primary/10" />
                </div>
                <div className="p-6 flex-grow">
                  <h3 className="text-lg font-bold text-primary mb-3 leading-tight">
                    {prod.name}
                  </h3>
                  <ul className="space-y-2">
                    {prod.specs.map((spec, j) => (
                      <li key={j} className="flex items-start text-muted-foreground text-sm">
                        <span className="text-accent mr-2 mt-0.5 font-bold">&bull;</span>
                        {spec}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="px-6 pb-6">
                  <Button
                    onClick={() => scrollToSection("contact")}
                    className="w-full bg-white hover:bg-accent text-primary hover:text-white border border-primary/20 hover:border-accent font-semibold transition-all duration-200"
                    data-testid={`product-quote-${i}`}
                  >
                    Get Quote
                  </Button>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <p className="text-center mt-10 text-muted-foreground font-medium text-base">
            10,000+ products available —{" "}
            <button
              onClick={() => scrollToSection("contact")}
              className="text-accent underline underline-offset-2 hover:text-primary transition-colors duration-200 font-semibold"
              data-testid="catalogue-link"
            >
              request full catalogue
            </button>
          </p>
        </div>
      </section>

      {/* ABOUT US */}
      <section id="about" className="py-24 bg-primary text-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                The Backbone of Veterinary Supply
              </h2>
              <div className="w-20 h-1.5 bg-accent mb-8" />
              <p className="text-lg text-blue-100 mb-8 leading-relaxed">
                Prime Agencies is a proprietorship firm established in 2014,
                specializing in wholesale distribution of veterinary products across
                Maharashtra. We serve veterinary clinics, hospitals, and businesses
                with a wide range of quality products.
              </p>

              <div className="space-y-4 bg-white/10 p-6 rounded-lg backdrop-blur-sm mb-8 border border-white/20">
                <div className="flex items-center">
                  <span className="font-semibold w-32 text-blue-200 shrink-0">GST No:</span>
                  <span className="font-mono">27AEMPA6554K1Z7</span>
                </div>
                <div className="flex items-center">
                  <span className="font-semibold w-32 text-blue-200 shrink-0">Legal Status:</span>
                  <span>Proprietorship Firm</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mb-10">
                {["10+ Years of Trust", "Quality Assured Products", "Nationwide Supply Chain"].map(
                  (badge, i) => (
                    <span
                      key={i}
                      className="px-4 py-2 bg-white/10 rounded-full text-sm font-medium border border-white/20"
                    >
                      {badge}
                    </span>
                  )
                )}
              </div>

              <div className="h-56 rounded-xl overflow-hidden border border-white/10 shadow-lg">
                <img
                  src="https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=600"
                  alt="Veterinary supply chain"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="h-[500px] rounded-2xl overflow-hidden shadow-2xl border border-white/10"
            >
              <img
                src="https://images.unsplash.com/photo-1587764379873-97837921fd44?q=80&w=2670&auto=format&fit=crop"
                alt="Veterinary products distribution"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Why Choose Prime Agencies
            </h2>
            <p className="text-muted-foreground text-lg">
              A decade of reliability, quality, and scale — built for the
              veterinary professionals who depend on us.
            </p>
          </div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={staggerContainer}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {whyChooseUs.map((item, i) => (
              <motion.div
                key={i}
                variants={fadeIn}
                className="group bg-white rounded-xl p-8 border border-border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
                style={{ borderTop: "3px solid transparent" }}
                onMouseEnter={(e) => (e.currentTarget.style.borderTopColor = "#f5820d")}
                onMouseLeave={(e) => (e.currentTarget.style.borderTopColor = "transparent")}
                data-testid={`why-card-${i}`}
              >
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 text-primary mb-5 group-hover:bg-accent/10 group-hover:text-accent transition-colors duration-200">
                  {item.icon}
                </div>
                <h3 className="text-lg font-bold text-foreground mb-3">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section id="contact" className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Partner With Us
            </h2>
            <p className="text-muted-foreground text-lg">
              Reach out for bulk inquiries, pricing, or to establish a supply
              relationship.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-0 max-w-6xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-border">
            {/* Contact Form */}
            <div className="p-8 md:p-12">
              <h3 className="text-2xl font-bold text-primary mb-6">Send an Inquiry</h3>
              <form
                method="POST"
                action="https://formspree.io/f/xjgzqewg"
                className="space-y-5"
              >
                <input type="hidden" name="_replyto" value="bhushandemo01@gmail.com" />

                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-sm font-semibold text-foreground">Name</label>
                    <input
                      name="name"
                      required
                      placeholder="Your Name"
                      className="w-full px-4 py-2.5 rounded-lg border border-border bg-secondary/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all duration-200"
                      data-testid="input-name"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-semibold text-foreground">Phone</label>
                    <input
                      name="phone"
                      required
                      placeholder="+91 98765 43210"
                      className="w-full px-4 py-2.5 rounded-lg border border-border bg-secondary/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all duration-200"
                      data-testid="input-phone"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-foreground">Email</label>
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="contact@clinic.com"
                    className="w-full px-4 py-2.5 rounded-lg border border-border bg-secondary/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all duration-200"
                    data-testid="input-email"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-foreground">Product Interest</label>
                  <select
                    name="product_interest"
                    className="w-full px-4 py-2.5 rounded-lg border border-border bg-secondary/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all duration-200 text-foreground"
                    data-testid="select-product-interest"
                  >
                    <option value="">Select a category...</option>
                    <option value="Veterinary Injection">Veterinary Injection</option>
                    <option value="Veterinary Medicine">Veterinary Medicine</option>
                    <option value="Dog Shampoo">Dog Shampoo</option>
                    <option value="Pet Products">Pet Products</option>
                    <option value="Veterinary Dry Injections">Veterinary Dry Injections</option>
                    <option value="Animal Feed Supplement">Animal Feed Supplement</option>
                    <option value="Antibacterial Drugs">Antibacterial Drugs</option>
                    <option value="Pharmaceutical Capsules">Pharmaceutical Capsules</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-foreground">Message</label>
                  <textarea
                    name="message"
                    rows={4}
                    placeholder="Tell us about your requirements..."
                    className="w-full px-4 py-2.5 rounded-lg border border-border bg-secondary/50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all duration-200 resize-none"
                    data-testid="input-message"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-accent hover:bg-accent/90 text-white font-bold h-12 text-base rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
                  data-testid="btn-submit"
                >
                  Submit Inquiry
                </button>
              </form>
            </div>

            {/* Contact Info & Map */}
            <div className="bg-secondary/30 p-8 md:p-12 border-t lg:border-t-0 lg:border-l border-border flex flex-col">
              <h3 className="text-2xl font-bold text-primary mb-6">Headquarters</h3>

              <div className="space-y-6 mb-8">
                <div>
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                    Address
                  </h4>
                  <p className="text-foreground font-medium leading-relaxed">
                    Patra Shed Station Road,<br />
                    Shed No 6,7,8,9,<br />
                    Ulhasnagar - 421004,<br />
                    Thane, Maharashtra
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                    Phone
                  </h4>
                  <a
                    href="tel:08043890867"
                    className="text-xl font-bold text-primary hover:text-accent transition-colors duration-200"
                    data-testid="link-phone"
                  >
                    08043890867
                  </a>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                    GST Number
                  </h4>
                  <p className="font-mono font-medium text-foreground">27AEMPA6554K1Z7</p>
                </div>
              </div>

              <div className="flex-grow min-h-[220px] rounded-xl overflow-hidden border border-border shadow-inner">
                <iframe
                  src="https://www.google.com/maps?q=Patra+Shed+Station+Road+Ulhasnagar+Maharashtra&output=embed"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: 220 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Prime Agencies Location"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-primary pt-16 pb-8 border-t border-white/10">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="text-2xl font-bold tracking-tight text-white mb-4">
                Prime <span className="text-accent">Agencies</span>
              </div>
              <p className="text-blue-200/80 max-w-sm leading-relaxed">
                Your trusted veterinary products wholesale distributor. Delivering
                excellence across Maharashtra since 2014.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white mb-6">Quick Links</h4>
              <ul className="space-y-3 text-blue-200/80">
                {["home", "products", "about", "contact"].map((link) => (
                  <li key={link}>
                    <button
                      onClick={() => scrollToSection(link)}
                      className="capitalize hover:text-accent transition-colors duration-200"
                      data-testid={`footer-link-${link}`}
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold text-white mb-6">Connect</h4>
              <div className="flex gap-4">
                {[
                  { icon: <FaFacebook size={18} />, label: "Facebook" },
                  { icon: <FaLinkedin size={18} />, label: "LinkedIn" },
                  { icon: <FaTwitter size={18} />, label: "Twitter" },
                ].map((social) => (
                  <a
                    key={social.label}
                    href="#"
                    aria-label={social.label}
                    className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-accent transition-all duration-200"
                    data-testid={`social-${social.label.toLowerCase()}`}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 text-center md:text-left flex flex-col md:flex-row justify-between items-center text-blue-200/60 text-sm gap-2">
            <p>© {new Date().getFullYear()} Prime Agencies. All Rights Reserved.</p>
            <p>Proprietorship Firm | GST: 27AEMPA6554K1Z7</p>
          </div>
        </div>
      </footer>

      {/* FLOATING WHATSAPP */}
      <a
        href="https://wa.me/918043890867?text=Hi%2C%20I%20want%20to%20enquire%20about%20your%20veterinary%20products"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 hover:shadow-xl transition-all duration-200"
        data-testid="whatsapp-float"
      >
        <FaWhatsapp size={30} />
      </a>

      {/* FLOATING CALL — mobile only */}
      <a
        href="tel:08043890867"
        className="fixed bottom-6 left-6 z-50 w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 hover:shadow-xl transition-all duration-200 md:hidden"
        data-testid="call-float"
        aria-label="Call Now"
      >
        <FaPhone size={22} />
      </a>
    </div>
  );
}
